<?php


namespace App\Actions;


use App\Traits\Responder;

abstract class AAction
{
    use Responder;

}