<?php

namespace App\Actions\Auth;

use App\Actions\AAction;
use App\Models\User;
use App\Repositories\TokenRepository;
use App\Repositories\UserRepository;
use Core\Validator\RequestValidator;
use Exception;
use Laminas\Diactoros\Response\JsonResponse;
use Psr\Http\Message\ServerRequestInterface;

class LoginAction extends AAction
{
    /**
     * @param ServerRequestInterface $request
     * @return JsonResponse
     * @throws Exception
     */
    public function __invoke(ServerRequestInterface $request): JsonResponse
    {
        $parsedBody = $request->getParsedBody();

        $result = RequestValidator::validate([
            'user_name' => 'required',
            'password' => 'required'
        ], $parsedBody);

        if (!empty($result)) {
            return $this->JsonResponse([], 422, 'Validation error', $result);
        }
        $rememberMe = isset($parsedBody['remember_me']) ? $parsedBody['remember_me'] : 0;
        $res = UserRepository::login($parsedBody['user_name'], $parsedBody['password'], $rememberMe);
        if ($res === null) {
            return $this->JsonResponse([], 422, 'Invalid credentials', [
                'Invalid password or user_name'
            ]);
        }
        if (empty($res)) {
            return $this->JsonResponse([], 404, 'Account not found');
        }

        return $this->JsonResponse($res);
    }
}