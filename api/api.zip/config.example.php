<?php
const DBDRIVER = 'mysql';
const DBHOST = 'mysql';
const DBNAME = 'db';
const DBUSER = 'root';
const DBPASS = '';