<?php
const DBDRIVER = 'mysql';
const DBHOST = 'localhost';
const DBNAME = 'test_db';
const DBUSER = 'root';
const DBPASS = '';
const JWT_KEY = 'sdlknvsdlkvndlskvdkslvkdsl';
const JWT_REFRESH_KEY = 'sldvnkkldsmverigprjome0';