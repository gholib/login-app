<?php

use Core\DB\Database;
require 'config.php';

//Initialize Illuminate Database Connection
new Database();